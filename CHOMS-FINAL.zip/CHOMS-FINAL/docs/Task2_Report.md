---
title: "MatCH Community Health & Outreach Management System (CHOMS)"
subtitle: "Task 2 - System Development Report | Work Integrated Learning 3 (XADAD7112w)"
---

**Module:** Work Integrated Learning 3 - XADAD7112w  
**Qualification:** Advanced Diploma in Application Development (ADAD113)  
**Client:** Maternal, Adolescent and Child Health Institute (MatCH), Durban  
**Group members:** [INSERT NAMES AND STUDENT NUMBERS HERE]  
**GitHub repository:** [INSERT GITHUB URL HERE] (lecturer added as collaborator)  
**Live system URL:** [INSERT FIREBASE HOSTING URL HERE]

# 1. Introduction

MatCH is a non-profit organisation in Durban that supports communities affected by HIV/TB and promotes maternal, adolescent and child health. In Task 1 we found that MatCH tracks beneficiaries, field visits, referrals and funder reporting on paper registers and disconnected spreadsheets. This causes duplicate records, lost referrals, delayed visibility for coordinators and a heavy manual reporting burden.

For Task 2 we built the **Community Health & Outreach Management System (CHOMS)**: a single responsive web application backed by a cloud database. Community Health Workers (CHWs) use it on their phones in the field, even without signal, while Programme Coordinators and Administrators use the same system on a desktop for scheduling, oversight, reporting and user management.

The system consists of:

* a **responsive front end** in HTML, CSS and JavaScript (ES modules) with a mobile-first CHW experience and a desktop dashboard experience;
* **Firebase Authentication** (email and password) for sign-in;
* **Cloud Firestore** as the cloud-based database, protected by **role-based Firestore Security Rules**;
* an **offline-first synchronisation layer** using browser localStorage;
* a **GitHub repository with a GitHub Actions pipeline** that runs Jest unit tests on every commit.

The hosted web app is wrapped with the Appilix tool so that it can be installed as an Android/iOS app.

**Change from the Task 1 design.** Task 1 proposed separate desktop and mobile applications talking to a custom REST API with Entity Framework Core. To deliver a working, maintainable solution within the module time and with free-tier cloud services, we consolidated this into one responsive web app that talks to Firebase directly. The architectural ideas from Task 1 are all retained (Section 4): the layered structure, the Repository pattern, offline-first/cache-aside, and role-based access control. RBAC moved from the API layer into Firestore Security Rules, which enforce it on the server.

[INSERT SCREENSHOT OF LOGIN PAGE HERE]

*Figure 1: CHOMS sign-in screen.*

# 2. Client Requirements Update

This section shows how the final system meets the functional (FR) and non-functional (NFR) requirements agreed with MatCH in Task 1.

## 2.1 Functional requirements

| # | Requirement | How the final system meets it | Where |
|---|---|---|---|
| FR1 | Register beneficiaries | Registration form with personal, demographic and programme details; South African ID number is validated (13 digits, date and Luhn checksum) and auto-fills date of birth and gender; **duplicate ID numbers are blocked**; POPIA consent is mandatory. | Beneficiaries |
| FR2 | CHWs open/manage case files | Each beneficiary has a **Case file** showing profile plus full history. CHWs see and edit only their own clients. | Case file button |
| FR3 | Record field visits offline-first with auto-sync | Visit form (date, location, outcome, notes). Saved to a localStorage outbox first, shown immediately, then synced automatically when the device is online. | Visits |
| FR4 | Coordinators schedule/allocate visits | Coordinators use **Schedule visit** and choose a CHW. The CHW sees it under "Visits to do" and taps **Complete** to record the outcome. | Visits |
| FR5 | Create/update/track referrals | Referral form (facility, reason, urgency, status, outcome). Pending/urgent referrals appear on the dashboard; completing a referral requires outcome notes. | Referrals |
| FR6 | Book/reschedule/cancel appointments with reminders | Full booking lifecycle. Changing the time automatically sets status *rescheduled*; Cancel clears the reminder. A reminder channel (SMS/e-mail) and a **reminder due time (24 h before)** are stored. *Limitation: the actual sending of SMS/e-mail needs a server-side component (Cloud Function + gateway) on a paid Firebase plan, so this is recorded as future work.* | Appointments |
| FR7 | Role-based access control | Three roles (Admin, Coordinator, CHW) enforced by Firestore Security Rules; the UI also hides actions the role cannot perform. | firestore.rules, utils.js |
| FR8 | Generate/review/approve/export funder reports | Report for any date range (new beneficiaries, visits, outcomes, visits per CHW, referral completion rate, appointment attendance rate). Coordinators save for approval; **only Admins approve**; export to CSV and print/PDF. | Reports |
| FR9 | Searchable case history | Live search across names, reference, ID, area, programme and phone; the case file shows visits, referrals and appointments together. | Beneficiaries |
| FR10 | Offline data sync | Outbox + cache with automatic sync on reconnect and a visible sync status chip with a manual *Sync now* button. | repo.js |
| FR11 | Admin user account management | Admins create users (Firebase login and profile), edit roles and deactivate/reactivate accounts. | Users |
| FR12 | Audit trail | Every create, update and delete writes an append-only audit entry (who, role, when, what). Only Admins can read it, nobody can edit or delete it. | Audit log |

## 2.2 Non-functional requirements

| NFR | How it is addressed |
|---|---|
| Security / POPIA | Firebase Authentication; Firestore Security Rules (RBAC); HTTPS/TLS in transit and Google-managed encryption at rest; mandatory consent field; ID numbers masked in lists; cached client data cleared from the device on sign-out; audit trail. |
| Usability | Mobile-first layout, large touch targets (44 px), bottom tab bar for CHWs, plain-language error messages, ID auto-fill, status badges. |
| Availability | Offline-first: app shell cached by a service worker, data cached in localStorage, writes queued in an outbox. |
| Performance | Role-scoped Firestore queries load only the data a user needs; reports are computed in the browser in milliseconds. |
| Scalability | Cloud Firestore scales automatically; no servers to manage. |
| Maintainability | Layered code (Section 4), documented modules, Git version control, automated tests, CI pipeline. |
| Reliability | Client-side validation on every form, try/catch around every cloud operation, server-side rules validation, parameterless NoSQL access (no SQL injection surface). |
| Portability | Runs in any modern browser; installable as Android/iOS app through Appilix; responsive from 360 px phones to desktops. |

[INSERT SCREENSHOT OF ADMIN DASHBOARD HERE]

*Figure 2: Admin / Coordinator dashboard with key statistics, work lists and visits per CHW.*

[INSERT SCREENSHOT OF CHW DASHBOARD ON MOBILE HERE]

*Figure 3: CHW dashboard on a phone with the bottom navigation bar.*

# 3. User Interface and Experience

The interface adapts to the user's device and role:

* **CHW (phone):** a bottom tab bar (Dashboard, Clients, Visits, Referrals, Appointments), a "Visits to do" list with one-tap *Complete*, and forms that hide fields the CHW does not need (the CHW is assigned automatically).
* **Coordinator / Admin (desktop):** a sidebar, statistics cards, data tables with search and status filters, a reports screen, and (Admin only) user management and the audit log.
* On narrow screens the data tables turn into stacked cards so nothing needs horizontal scrolling.
* Accessibility: labelled fields, visible focus outlines, error messages announced with `role="alert"`, colour is never the only status indicator (badges carry text).

[INSERT SCREENSHOT OF BENEFICIARY REGISTRATION FORM HERE]

*Figure 4: Beneficiary registration form with validation messages.*

[INSERT SCREENSHOT OF CHW VISIT FORM HERE]

*Figure 5: CHW visit recording form.*

[INSERT SCREENSHOT OF CASE FILE HERE]

*Figure 6: Beneficiary case file showing visit, referral and appointment history.*

[INSERT SCREENSHOT OF REFERRALS AND APPOINTMENTS SCREENS HERE]

*Figure 7: Referral and appointment management.*

[INSERT SCREENSHOT OF REPORTS SCREEN HERE]

*Figure 8: Programme report generation, approval and export.*

[INSERT SCREENSHOT OF USER MANAGEMENT SCREEN HERE]

*Figure 9: Admin user management.*

# 4. Technical Architecture

## 4.1 Technology stack

| Concern | Technology |
|---|---|
| Front end | HTML5, CSS3 (responsive, no framework), JavaScript ES modules |
| Authentication | Firebase Authentication (email/password) |
| Cloud database | Cloud Firestore (NoSQL document database) |
| Access control | Firestore Security Rules |
| Offline | Service worker (app shell) + localStorage (data cache and outbox) |
| Hosting | Firebase Hosting (HTTPS) |
| Mobile packaging | Appilix (wraps the hosted web app) |
| Version control / CI | Git, GitHub, GitHub Actions |
| Testing | Jest |

## 4.2 Layered architecture

The Task 1 layered (N-tier) design is preserved:

| Layer | Files | Responsibility |
|---|---|---|
| Presentation | `index.html`, `css/style.css`, `js/app.js`, `js/ui.js`, `js/entities.js` | Screens, forms, routing, events |
| Business logic | `js/utils.js` | Validation, RBAC matrix, date/ID logic, report calculations - pure functions with unit tests |
| Data access | `js/repo.js`, `js/firebase.js` | **Repository pattern**: the only code that talks to Firestore; handles caching and sync |
| Cloud | Firebase Auth, Firestore, `firestore.rules` | Identity, storage, server-side enforcement |

[INSERT ARCHITECTURE DIAGRAM HERE] *(Suggested: draw the four layers above with the CHW phone and Admin desktop at the top and Firebase at the bottom, using draw.io or Visio.)*

## 4.3 Project file structure

```
match-choms/
  index.html            css/style.css
  js/ app.js  ui.js  entities.js  utils.js  repo.js  firebase.js  firebase-config.js
  sw.js  manifest.json  icon.svg
  firestore.rules  firebase.json
  tests/utils.test.js   package.json
  .github/workflows/main.yml
  SETUP.md   docs/
```

Code is split by responsibility so the system can be extended: for example a new entity only needs a definition in `entities.js` and a rule block in `firestore.rules`.

## 4.4 Design patterns used

* **Repository pattern** - `repo.js` hides Firestore behind `list`, `save`, `remove` and `flush`.
* **Offline-first / Cache-aside + Outbox** - see 4.6.
* **Role-Based Access Control** - at UI level (`can()`), and at data level (security rules).
* **Declarative entity configuration** - one generic form/table engine renders all four entities, avoiding duplicated code.

## 4.5 Cloud database design

Cloud Firestore stores data in collections of documents:

| Collection | Purpose | Key fields |
|---|---|---|
| `users` | Profile and role of each login (document ID = Firebase UID) | name, email, role, active |
| `beneficiaries` | Clients/case files | ref, firstName, lastName, idNumber, dob, gender, phone, area, programme, enrolmentDate, assignedChwId, status, consent |
| `visits` | Field visits | beneficiaryId, chwId, date, status, location, outcome, notes |
| `referrals` | Referrals to external facilities | beneficiaryId, chwId, facility, reason, urgency, referralDate, status, outcomeNotes |
| `appointments` | Appointments and reminders | beneficiaryId, chwId, datetime, purpose, status, reminderChannel, reminderDue |
| `reports` | Saved funder reports | from, to, summaryJson, status, generatedBy, approvedBy |
| `auditLogs` | Immutable change history | action, collection, docId, summary, userId, userName, role, at |

Relationships are held by IDs (for example `visits.beneficiaryId` points to a beneficiary) - the document-database equivalent of the foreign keys in the Task 1 ER diagram.

[INSERT SCREENSHOT OF FIRESTORE DATABASE IN FIREBASE CONSOLE HERE]

*Figure 10: Cloud Firestore collections and documents in the Firebase console, showing the database is cloud-based.*

**Database connectivity.** The browser connects to Firestore over HTTPS/WebSockets through the Firebase SDK, initialised once in `firebase.js` using the project configuration. Every screen reads and writes through `repo.js`, so connectivity works throughout the system.

## 4.6 How offline-first caching works

1. **Reading (cache-aside).** `repo.list()` asks Firestore for the data. On success the result is stored in localStorage under a key containing the user's ID. If the device is offline or the request fails, the cached copy is returned instead.
2. **Writing (outbox).** Every create, update or delete is first appended to an *outbox* in localStorage and is immediately visible in the screens, because pending operations are overlaid on the cached data. The document ID is generated on the device, so new records can be created without a connection.
3. **Synchronising.** When the browser fires the `online` event (or the user taps *Sync now*, or every 60 seconds while changes are pending) the outbox is replayed to Firestore in order. Operations use `setDoc(..., {merge:true})` or `deleteDoc`, so replaying one that already reached the server is harmless (idempotent).
4. **Rejected operations.** If the server rejects an operation permanently (for example `permission-denied`), it is moved to a "failed" list and the user is told, so one bad item never blocks the queue.
5. **Visibility.** A status chip always shows *Online/Offline* and the number of pending changes; an amber banner appears when offline.
6. **Offline start-up.** A service worker caches the app files, and Firebase Authentication keeps the session, so a CHW can open the app with no signal after the first sign-in.
7. **Privacy.** On sign-out, if everything has synced, the cached client data is deleted from the device. Each CHW only ever caches their own clients.

[INSERT SCREENSHOT OF OFFLINE BANNER AND PENDING CHANGES CHIP HERE]

*Figure 11: Visit recorded while offline - pending change indicator.*

[INSERT SCREENSHOT OF CHANGES SYNCED TO THE CLOUD HERE]

*Figure 12: Same record synchronised to Firestore after reconnecting.*

# 5. Security and Error Handling

## 5.1 Authentication

* Users sign in through **Firebase Authentication**. Passwords are never stored by our code; Firebase stores salted hashes.
* There is no public self-registration. Admins create accounts (Users screen). The first Admin is created manually in the Firebase console (see SETUP.md).
* After sign-in the app loads the user's profile from `users/{uid}`. Accounts without a profile, or marked deactivated, are signed out immediately with an explanatory message.
* The login form limits attempts (60-second lock after 5 failures) in addition to Firebase's own throttling, and shows a single generic message ("Incorrect email or password") so it never reveals whether an email exists.
* Password reset by e-mail is supported; new passwords must have 8+ characters with upper-case, lower-case and a number.

## 5.2 Role-based access control (RBAC)

| Capability | CHW | Coordinator | Admin |
|---|---|---|---|
| Beneficiaries | Own clients only (read/create/update) | All (no delete) | All |
| Visits, referrals, appointments | Own only (full CRUD) | All | All |
| Schedule visits for others | No | Yes | Yes |
| Reports | No | Create / save | Create / **approve** |
| Users | No | Read (CHW list for allocation) | Full management |
| Audit log | No | No | Read |

RBAC is enforced in two places:

1. **UI level** - `can(role, action, collection)` hides buttons and menu items the user may not use.
2. **Server level (authoritative)** - `firestore.rules` checks the caller's role (read from `users/{uid}`) on every request. For example, a CHW can read a visit only when `resource.data.chwId == request.auth.uid`; the front end additionally queries with the same filter so these reads are allowed. A user whose `active` flag is false is denied everything. The final rule denies any collection not explicitly listed.

[INSERT SCREENSHOT OF FIRESTORE SECURITY RULES HERE]

*Figure 13: Security rules published in the Firebase console.*

[INSERT SCREENSHOT OF RULES PLAYGROUND DENYING A CHW READING ANOTHER CHW'S VISIT HERE]

*Figure 14: Rules Playground test - access correctly denied.*

## 5.3 Data protection (POPIA)

* Informed consent must be ticked before a beneficiary can be saved (client check and server rule).
* Data is transmitted over HTTPS and encrypted at rest by Google Cloud. Database location can be chosen in South Africa when available.
* ID numbers are masked in lists (only the last four digits are shown).
* CHWs only receive their own clients' data on the device; cached data is wiped on sign-out.
* All changes are recorded in an immutable audit trail.
* Records are deactivated rather than hard-deleted for users, preserving history.

## 5.4 Input validation and injection protection

* Every form is validated in `utils.js` before saving: required fields, lengths, formats (SA ID with checksum, South African phone numbers, e-mail), plausible dates (no future birth dates, no past bookings), and cross-field logic (completed visits need an outcome and notes; completed referrals need outcome notes).
* Text is sanitised (control characters removed, spaces collapsed, length capped) and **escaped before display** (`escapeHtml`) to prevent cross-site scripting.
* Firestore is a NoSQL document store accessed through typed SDK calls, so there is no SQL string building and therefore no SQL injection surface. Security rules also validate key fields on the server.
* CSV export protects against spreadsheet formula injection.
* A Content-Security-Policy in `index.html` limits where scripts can load from.

## 5.5 Error handling

* **try/catch** surrounds every cloud operation (login, loading, saving, deleting, syncing, user creation, report actions).
* `friendlyError()` converts technical Firebase codes (for example `permission-denied`, `unavailable`, `auth/too-many-requests`) into plain messages such as "The server is unreachable. Your changes are saved on this device and will sync later."
* Form errors appear beside the field, the first invalid field receives focus, and a summary message is shown; the Save button is disabled while saving to prevent double submission.
* Toast notifications confirm success or failure; global handlers catch unexpected errors and unhandled promise rejections so the app does not fail silently.
* Network timeouts (10-12 s) prevent the interface from hanging on poor mobile connections.
* Storage-full or blocked localStorage is handled without crashing.
* Failed sync operations are reported to the user instead of being lost.

[INSERT SCREENSHOT OF FORM VALIDATION ERRORS HERE]

*Figure 15: Validation messages on the registration form.*

[INSERT SCREENSHOT OF FRIENDLY ERROR MESSAGE (E.G. WRONG PASSWORD) HERE]

*Figure 16: Friendly error message on failed login.*

[INSERT SCREENSHOT OF AUDIT LOG HERE]

*Figure 17: Audit trail visible to Administrators.*

# 6. DevOps and Testing

## 6.1 Version control

All code is stored in a GitHub repository ([INSERT GITHUB URL HERE]). The lecturer has been added as a collaborator. Commits show the work of each team member [INSERT SCREENSHOT OF GITHUB COMMIT HISTORY HERE].

## 6.2 GitHub Actions pipeline

The workflow `.github/workflows/main.yml` runs on every push and pull request. It checks out the code, installs Node.js (versions 20 and 22), installs dependencies with `npm ci`, runs the Jest test suite with coverage and uploads the coverage report. A failing test turns the commit red.

[INSERT SCREENSHOT OF GITHUB ACTIONS RUN (GREEN TICK) HERE]

*Figure 18: Successful pipeline run.*

## 6.3 Unit tests

The business logic is isolated in `js/utils.js` and covered by **48 Jest unit tests**, including SA ID validation (Luhn checksum, extracting date of birth and gender), age and date calculations, phone/e-mail/password validation, beneficiary/visit/referral/appointment validators (including duplicate detection and consent), the RBAC permission matrix and report calculations. The full list and manual test cases are in the Testing Evidence document.

[INSERT SCREENSHOT OF JEST TEST RESULTS HERE]

*Figure 19: Jest output - all tests passing.*

# 7. Challenges Experienced and How We Solved Them

| Challenge | Solution |
|---|---|
| Task 1 specified separate desktop and mobile apps and a REST API | Consolidated into one responsive web app with Firebase, keeping the layered architecture, repository pattern and RBAC |
| CHWs work in areas with poor or no signal | Offline-first outbox with idempotent sync, service worker and a visible sync status |
| Admins must create accounts without being signed out | A temporary secondary Firebase app instance creates the login, then is discarded |
| Preventing a CHW from seeing other CHWs' data | Role-scoped queries on the client **and** matching Firestore rules on the server |
| Client data stored on shared phones | Cache cleared on sign-out; each CHW caches only their own clients |
| Sending SMS/e-mail reminders needs a server | Reminders are queued (channel + due time stored); sending is documented as future work using a Cloud Function and SMS gateway |
| Keeping validation consistent | One set of pure functions shared by all forms and covered by unit tests |

[INSERT REFLECTION ON CHALLENGES SPECIFIC TO YOUR GROUP HERE]

# 8. Conclusion

CHOMS replaces MatCH's paper registers and spreadsheets with a single secure cloud-based system. All twelve functional requirements from Task 1 are implemented, with one stated limitation: reminder messages are queued but not yet sent, because delivery needs a paid server-side component. The system works on phones and desktops, keeps working without a signal and synchronises automatically, so CHWs can record visits in the field without double-entry. Coordinators gain immediate visibility of visits, referrals and appointments, and funder reports that previously took hours can be produced, approved and exported in seconds. Security is built in through Firebase Authentication, server-enforced role-based access, input validation, POPIA-aware data handling and an immutable audit trail. The GitHub Actions pipeline and unit tests protect the quality of the code as the system grows.

**Recommended future work:** automated SMS/e-mail reminders using Cloud Functions; field-level encryption of cached offline data; push notifications for overdue visits and urgent referrals; and integration with provincial health information systems.

# 9. Declaration

[INSERT SIGNED DECLARATION OF AUTHENTICITY (ANNEXURE A) HERE]

# 10. References

[INSERT HARVARD-STYLE REFERENCES HERE - e.g. Firebase documentation (Google, 2026), Jest documentation, GitHub Actions documentation, POPIA (Act 4 of 2013), and the IIE Module Manual XADAD7112/w.]
