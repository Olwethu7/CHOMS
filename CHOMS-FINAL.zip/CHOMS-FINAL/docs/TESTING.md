# Deliverable 5 - Testing Evidence

## 1. Automated unit tests (Jest) - `tests/utils.test.js`

All business rules live in `js/utils.js` (no DOM / Firebase), so they are tested in plain Node. **48 tests, all passing.**

| Group | Tests (what is proven) |
|---|---|
| Text helpers | `escapeHtml` neutralises `<img onerror>` (XSS); `sanitizeText` trims, collapses spaces, caps length, keeps line breaks for notes |
| Date helpers | `isValidISODate` rejects 2026-02-30 / month 13; `isValidDateTime`; `daysBetween` (normal, leap year, negative, invalid); `addDays` across month/year; `calcAge` before/after birthday and future dob; `reminderDueAt` = 24 h before; `isFutureDate`; `formatDate` |
| SA ID number | Luhn checksum; valid IDs return date of birth + gender; rejects wrong length, letters, bad checksum, impossible dates |
| Contact / password | `normalisePhone` (4 accepted formats -> `+27...`, rejects bad numbers); `isValidEmail`; `validatePassword` rules; `generateRef`; `maskId` |
| validateBeneficiary (FR1) | accepts valid record; derives dob/gender from ID; flags dob that contradicts ID; **duplicate ID detection** (but allows editing the same record); POPIA consent / area / programme / CHW required; future dob, bad names, bad phone; apostrophes/hyphens allowed; `<script>` name rejected |
| validateVisit (FR3/FR4) | valid completed visit; completed needs outcome + notes + non-future date; scheduled may be future but not past |
| validateReferral (FR5) | valid referral; completed requires outcome notes; unknown urgency / future date rejected |
| validateAppointment (FR6) | valid booking sets `reminderDue`; past booking rejected but past *attended* allowed; no reminder when channel is none |
| RBAC matrix (FR7) | admin everything; coordinator cannot delete beneficiaries / read users / approve reports; CHW has no reports/users/audit; unknown role denied |
| Reporting (FR8) | counts only items in date range; attendance and completion rates; empty data does not divide by zero; CSV escaping + formula-injection guard; multi-term search |

Run locally: `npm install && npm test` (coverage: `npm run test:coverage`).

## 2. How the tests run in GitHub Actions

File: `.github/workflows/main.yml`

1. **Trigger:** `on: push` and `pull_request` - every commit, on any branch.
2. **Runner:** a fresh `ubuntu-latest` virtual machine, repeated for Node 20 and Node 22 (matrix build).
3. **Steps:** `actions/checkout` -> `actions/setup-node` (with npm cache) -> `npm ci` (clean, locked install) -> `npm run test:coverage` (Jest).
4. **Result:** Jest exits non-zero if any test fails, which turns the workflow red and marks the commit with a red cross; all green = tick. The coverage report is uploaded as a downloadable artifact.
5. **Why it matters:** a developer cannot silently break ID validation, the RBAC matrix or report maths - the pipeline catches it within a minute (Continuous Integration).

## 3. Additional tests you can write (ideas for extension)

* `repo.js` outbox: mock `localStorage` and Firestore - verify a write is queued offline, flushed in order online, and that a `permission-denied` op is parked instead of blocking the queue.
* `applyOutbox`: pending delete hides a cached row; pending update overlays server data.
* Date edge cases: appointment at 23:59 / 00:00, leap-day birthdays.
* `friendlyError` maps every Firebase error code to a readable message.
* Firestore rules tests with `@firebase/rules-unit-testing` + the emulator (needs Java).

## 4. Manual / functional test cases (screenshot as evidence)

| ID | Test | Steps | Expected | Result |
|----|------|-------|----------|--------|
| M1 | Login - wrong password | Enter valid email + wrong password | "Incorrect email or password." no details leaked | |
| M2 | Login lockout | 5 wrong attempts | 60 s lock message | |
| M3 | Beneficiary validation | Save empty form | Red field errors, focus on first field | |
| M4 | ID auto-fill | Type valid 13-digit ID | DOB + gender fill automatically | |
| M5 | Duplicate ID (Admin/Coordinator) | Register same ID twice | "already registered" | |
| M6 | POPIA consent | Untick consent, Save | Blocked with consent message | |
| M7 | CHW isolation | Sign in as CHW-A | Only CHW-A's clients/visits/referrals/appointments visible | |
| M8 | Offline visit | Turn on airplane mode, record a visit | Saved; chip shows "Offline - 1 pending" | |
| M9 | Auto-sync | Turn airplane mode off | "1 change synced to the cloud"; record in Firestore console | |
| M10 | Schedule visit (Coordinator) | Visits -> Schedule visit -> assign CHW | CHW sees it under "Visits to do", can tap Complete | |
| M11 | Reschedule | Edit appointment time | Status becomes `rescheduled` | |
| M12 | Cancel appointment | Cancel button | Status `cancelled`, reminder cleared | |
| M13 | Report | Reports -> pick dates -> Generate -> Save | Shows as pending; Coordinator cannot approve | |
| M14 | Approve + export | Admin approves; Export CSV | Status approved; CSV opens in Excel | |
| M15 | Create user | Admin -> Users -> Add user | New login works; admin stays signed in | |
| M16 | Deactivate user | Deactivate then sign in as that user | Sign-in refused: account deactivated | |
| M17 | Audit trail | Make a change, open Audit log | Entry with user, role, time, detail | |
| M18 | Rules Playground | See table in `SETUP.md` | All 8 rows behave as expected | |
| M19 | Responsive | Resize to 390 px wide | Tab bar appears, tables become cards | |

## 5. Automated UI smoke test performed during development

A headless Chromium run drove the real app code against an in-memory stand-in for Firebase and passed **37/37 checks**: login errors, CHW data scoping, form validation, ID auto-fill, CRUD for all four entities, offline queue + sync, coordinator and admin permissions, report generate/save/approve, user creation and the audit trail. This is a development check of the app's logic; it does **not** replace testing against your real Firebase project (M1-M19 above).
