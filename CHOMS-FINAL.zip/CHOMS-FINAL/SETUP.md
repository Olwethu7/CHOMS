# MatCH CHOMS - Setup Guide

Single responsive web app (HTML / CSS / JavaScript) + Firebase Authentication + Cloud Firestore.
Works on a phone (Community Health Workers) and a desktop (Coordinators / Admins). Wrap the hosted URL with **Appilix** for the Android/iOS app.

```
match-choms/
├── index.html              # app shell: login, sidebar, views
├── css/style.css           # responsive styling (mobile-first + desktop sidebar)
├── js/
│   ├── firebase-config.js  # <-- YOU paste your Firebase config here
│   ├── firebase.js         # SDK initialisation + secondary-auth helper
│   ├── repo.js             # Repository layer: Firestore access, localStorage cache, offline outbox, sync
│   ├── utils.js            # Business logic: validators, RBAC matrix, reports (unit tested)
│   ├── entities.js         # Field/column definitions for Beneficiaries, Visits, Referrals, Appointments
│   ├── ui.js               # Toasts, modals, form builder, error-message mapping
│   └── app.js              # Controller: login, router, dashboards, CRUD, reports, users, audit
├── sw.js, manifest.json, icon.svg   # offline app shell (PWA)
├── firestore.rules         # RBAC security rules (deploy to Firebase)
├── firebase.json           # Firebase Hosting + rules deployment config
├── tests/utils.test.js     # Jest unit tests
├── package.json            # Jest configuration
└── .github/workflows/main.yml   # GitHub Actions pipeline
```

---

## 1. Create the Firebase project (free Spark plan)

1. Go to <https://console.firebase.google.com> and sign in with a Google account.
2. **Add project** -> name it `match-choms` -> (Google Analytics is optional; you can turn it off) -> **Create project**.
3. **Build -> Authentication -> Get started -> Sign-in method -> Email/Password -> Enable -> Save.**
4. **Build -> Firestore Database -> Create database**
   * Edition: Standard, mode: **Production mode** (the rules below will be deployed straight after)
   * Location: choose `africa-south1 (Johannesburg)` if offered (keeps data in South Africa - relevant for POPIA), otherwise the closest region. *The location cannot be changed later.*
5. **Project settings (gear icon) -> General -> Your apps -> Web (`</>`)** -> nickname `choms-web` -> **Register app**.
   Copy the `firebaseConfig` values into **`js/firebase-config.js`**.

## 2. Deploy the security rules

Option A - copy/paste (easiest): **Firestore Database -> Rules** tab -> replace everything with the contents of `firestore.rules` -> **Publish**.

Option B - CLI:
```bash
npm install -g firebase-tools
firebase login
firebase use --add            # pick your project
firebase deploy --only firestore:rules
```

## 3. Create the first Administrator (one-time bootstrap)

The app lets an Admin create all other users, but the very first Admin must be created by hand:

1. **Authentication -> Users -> Add user** -> email + password. Copy the generated **User UID**.
2. **Firestore Database -> Start collection** -> Collection ID `users` -> Document ID = **the UID you copied** -> add fields:

| Field    | Type    | Value                    |
|----------|---------|--------------------------|
| name     | string  | Your full name           |
| email    | string  | the same email           |
| role     | string  | `admin`                  |
| active   | boolean | `true`                   |

3. Sign in to the app as that user -> **Users -> + Add user** to create Coordinators and CHWs (each gets their own Firebase login).

## 4. Run it locally

Browsers block ES modules from `file://`, so serve the folder:
```bash
cd match-choms
npx http-server . -p 8080 -c-1        # or: python3 -m http.server 8080
# open http://localhost:8080
```
(`localhost` is already an authorised domain in Firebase Auth.)

## 5. Host it (needed for Appilix) - Firebase Hosting, free

```bash
firebase init hosting     # public dir: .   | single-page app: No | overwrite index.html: No
firebase deploy
```
You get `https://<project-id>.web.app`. Add that domain under **Authentication -> Settings -> Authorised domains** if it is not there already.

## 6. Turn it into a mobile app with Appilix

1. Go to <https://appilix.com> -> create an app -> paste your `https://<project-id>.web.app` URL.
2. Set the name (MatCH CHOMS), icon (`icon.svg` exported as PNG) and build the Android APK / iOS package.
3. Because the app is a PWA with offline caching, CHWs can open it without signal after the first sign-in.

## 7. GitHub + pipeline

```bash
git init
git add .
git commit -m "CHOMS Task 2: web app, rules, tests, pipeline"
git branch -M main
git remote add origin https://github.com/<you>/match-choms.git
git push -u origin main
```
* **Add your lecturer as a collaborator:** repo -> Settings -> Collaborators -> Add people.
* Every push triggers **Actions -> CHOMS CI - unit tests**. Take a screenshot of the green tick for your report.
* Run the tests locally any time: `npm install && npm test`.

---

## Rules Playground checks (evidence for the report)

Firebase Console -> Firestore -> Rules -> **Rules Playground**. Add the users docs first (Section 3), then simulate:

| # | Simulate            | Location                          | Authenticated as   | Expected |
|---|---------------------|-----------------------------------|--------------------|----------|
| 1 | get                 | `/visits/{any id of CHW-A's visit}` | UID of CHW-A       | Allow    |
| 2 | get                 | `/visits/{id of CHW-A's visit}`     | UID of CHW-B       | **Deny** |
| 3 | get                 | `/users/{other user's uid}`         | UID of a CHW       | **Deny** |
| 4 | update              | `/reports/{id}` setting `status:'approved'` | Coordinator | **Deny** |
| 5 | update              | `/reports/{id}` setting `status:'approved'` | Admin       | Allow    |
| 6 | delete              | `/beneficiaries/{id}`               | Coordinator        | **Deny** |
| 7 | get                 | `/auditLogs/{id}`                   | Coordinator        | **Deny** |
| 8 | get / any           | any path, unauthenticated           | (none)             | **Deny** |

## Notes / limitations (be upfront about these in your report)

* **SMS / e-mail reminders (FR6):** the app stores the chosen channel and a `reminderDue` timestamp (24 h before) on each appointment. Actually *sending* messages needs a server component (Cloud Function + SMS gateway or the "Trigger Email" extension), which requires Firebase's pay-as-you-go plan. It is documented as future work.
* **Offline storage** is browser `localStorage` (not encrypted). The app clears cached client data on sign-out when everything has synced, and each CHW only ever caches their own clients.
* Firebase **web API keys are not secrets**; protection comes from Authentication + the security rules.
