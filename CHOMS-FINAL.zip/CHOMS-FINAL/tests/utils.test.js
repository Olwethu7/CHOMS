import {
  escapeHtml, sanitizeText, isValidISODate, isValidDateTime, daysBetween, addDays, calcAge,
  reminderDueAt, luhnValid, parseSAId, normalisePhone, isValidEmail, validatePassword,
  generateRef, maskId, validateBeneficiary, validateVisit, validateReferral, validateAppointment,
  can, summariseActivity, toCSV, matchesSearch, isFutureDate, formatDate
} from '../js/utils.js';

const NOW = new Date(2026, 9, 15, 12, 0); // 15 Oct 2026 12:00 local
const VALID_ID_F = '1503120123080'; // female, 2015-03-12
const VALID_ID_M = '7806155123089'; // male, 1978-06-15

const goodBeneficiary = (over = {}) => ({
  firstName: 'Nomsa', lastName: 'Dlamini', idNumber: '', dob: '1995-04-20', gender: 'female',
  phone: '082 123 4567', area: 'Umlazi', programme: 'Maternal Health',
  enrolmentDate: '2026-09-01', assignedChwId: 'chw1', consent: true, ...over
});

describe('text helpers', () => {
  test('escapeHtml neutralises markup', () => {
    expect(escapeHtml('<img src=x onerror="a()">')).toBe('&lt;img src=x onerror=&quot;a()&quot;&gt;');
    expect(escapeHtml(null)).toBe('');
  });
  test('sanitizeText trims, collapses spaces and caps length', () => {
    expect(sanitizeText('  Hello    world \n ', 50)).toBe('Hello world');
    expect(sanitizeText('abcdef', 3)).toBe('abc');
  });
  test('sanitizeText multiline keeps line breaks', () => {
    expect(sanitizeText('a\nb', 50, { multiline: true })).toBe('a\nb');
  });
});

describe('date helpers', () => {
  test('isValidISODate rejects impossible dates', () => {
    expect(isValidISODate('2026-02-28')).toBe(true);
    expect(isValidISODate('2026-02-30')).toBe(false);
    expect(isValidISODate('2026-13-01')).toBe(false);
    expect(isValidISODate('15/10/2026')).toBe(false);
  });
  test('isValidDateTime', () => {
    expect(isValidDateTime('2026-10-20T09:30')).toBe(true);
    expect(isValidDateTime('2026-10-20T25:30')).toBe(false);
    expect(isValidDateTime('2026-10-20')).toBe(false);
  });
  test('daysBetween counts whole days incl. leap years', () => {
    expect(daysBetween('2026-10-01', '2026-10-15')).toBe(14);
    expect(daysBetween('2028-02-28', '2028-03-01')).toBe(2);
    expect(daysBetween('2026-10-15', '2026-10-01')).toBe(-14);
    expect(daysBetween('bad', '2026-10-01')).toBeNaN();
  });
  test('addDays crosses month and year boundaries', () => {
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01');
    expect(addDays('2026-03-01', -1)).toBe('2026-02-28');
  });
  test('calcAge handles birthdays not yet reached', () => {
    expect(calcAge('1995-10-15', NOW)).toBe(31);
    expect(calcAge('1995-10-16', NOW)).toBe(30);
    expect(calcAge('2030-01-01', NOW)).toBeNull();
    expect(calcAge('nope', NOW)).toBeNull();
  });
  test('reminderDueAt is 24h before', () => {
    expect(reminderDueAt('2026-11-01T09:00')).toBe('2026-10-31T09:00');
    expect(reminderDueAt('x')).toBe('');
  });
  test('isFutureDate / formatDate', () => {
    expect(isFutureDate('2026-10-16', NOW)).toBe(true);
    expect(isFutureDate('2026-10-15', NOW)).toBe(false);
    expect(formatDate('2026-10-15')).toBe('15/10/2026');
    expect(formatDate('')).toBe('-');
  });
});

describe('SA ID number validation', () => {
  test('luhnValid', () => {
    expect(luhnValid('8001015009087')).toBe(true);
    expect(luhnValid('8001015009088')).toBe(false);
  });
  test('valid IDs return dob and gender', () => {
    expect(parseSAId(VALID_ID_F, NOW)).toMatchObject({ valid: true, dob: '2015-03-12', gender: 'female', citizen: true });
    expect(parseSAId(VALID_ID_M, NOW)).toMatchObject({ valid: true, dob: '1978-06-15', gender: 'male' });
  });
  test('rejects wrong length, letters and bad checksum', () => {
    expect(parseSAId('12345').valid).toBe(false);
    expect(parseSAId('78061551230AB').valid).toBe(false);
    expect(parseSAId('7806155123088', NOW).valid).toBe(false);
  });
  test('rejects impossible birth dates', () => {
    expect(parseSAId('9913315009080', NOW).valid).toBe(false);
  });
});

describe('contact + password validation', () => {
  test.each([
    ['0821234567', '+27821234567'], ['082 123 4567', '+27821234567'],
    ['+27 82 123 4567', '+27821234567'], ['27821234567', '+27821234567']
  ])('normalisePhone(%s)', (input, out) => expect(normalisePhone(input)).toBe(out));
  test('normalisePhone rejects bad numbers', () => {
    expect(normalisePhone('12345')).toBeNull();
    expect(normalisePhone('0921234567')).toBeNull();
    expect(normalisePhone('')).toBeNull();
  });
  test('isValidEmail', () => {
    expect(isValidEmail('chw@match.org.za')).toBe(true);
    expect(isValidEmail('not-an-email')).toBe(false);
  });
  test('validatePassword rules', () => {
    expect(validatePassword('short1A')).toMatch(/8 characters/);
    expect(validatePassword('alllowercase1')).toMatch(/upper-case/);
    expect(validatePassword('GoodPass123')).toBe('');
  });
  test('generateRef and maskId', () => {
    expect(generateRef('abc12xyz', 2026)).toBe('MCH-2026-ABC12');
    expect(maskId('7806155123089')).toBe('*********3089');
    expect(maskId('')).toBe('-');
  });
});

describe('validateBeneficiary', () => {
  test('accepts a complete record and normalises the phone', () => {
    const r = validateBeneficiary(goodBeneficiary(), { now: NOW });
    expect(r.valid).toBe(true);
    expect(r.data.phone).toBe('+27821234567');
  });
  test('derives dob and gender from a valid ID', () => {
    const r = validateBeneficiary(goodBeneficiary({ idNumber: VALID_ID_F, dob: '', gender: '' }), { now: NOW });
    expect(r.valid).toBe(true);
    expect(r.data.dob).toBe('2015-03-12');
    expect(r.data.gender).toBe('female');
  });
  test('flags dob that contradicts the ID number', () => {
    const r = validateBeneficiary(goodBeneficiary({ idNumber: VALID_ID_F, dob: '1990-01-01' }), { now: NOW });
    expect(r.errors.dob).toMatch(/does not match/);
  });
  test('detects duplicate ID numbers but allows editing the same record', () => {
    const existing = [{ id: 'b1', idNumber: VALID_ID_M, firstName: 'Sipho', lastName: 'Zulu' }];
    const rec = goodBeneficiary({ idNumber: VALID_ID_M, dob: '', gender: '' });
    expect(validateBeneficiary(rec, { existing, now: NOW }).errors.idNumber).toMatch(/already registered/);
    expect(validateBeneficiary(rec, { existing, id: 'b1', now: NOW }).valid).toBe(true);
  });
  test('requires POPIA consent, area, programme and CHW', () => {
    const r = validateBeneficiary(goodBeneficiary({ consent: false, area: '', programme: '', assignedChwId: '' }), { now: NOW });
    expect(Object.keys(r.errors)).toEqual(expect.arrayContaining(['consent', 'area', 'programme', 'assignedChwId']));
  });
  test('rejects future dob, bad names and bad phone', () => {
    const r = validateBeneficiary(goodBeneficiary({ dob: '2030-01-01', firstName: '12', phone: '123' }), { now: NOW });
    expect(r.errors.dob).toMatch(/future/);
    expect(r.errors.firstName).toBeDefined();
    expect(r.errors.phone).toBeDefined();
  });
  test('accepts names with apostrophes and hyphens', () => {
    expect(validateBeneficiary(goodBeneficiary({ lastName: "Ngcobo-O'Neil" }), { now: NOW }).valid).toBe(true);
  });
  test('script tags in free text are rejected as names / neutralised in address', () => {
    expect(validateBeneficiary(goodBeneficiary({ firstName: '<script>alert(1)</script>' }), { now: NOW }).errors.firstName).toBeDefined();
  });
});

describe('validateVisit', () => {
  const base = { beneficiaryId: 'b1', chwId: 'c1', status: 'completed', date: '2026-10-10', location: 'Umlazi Section K', outcome: 'Stable - no action needed', notes: 'Client doing well, adherence good.' };
  test('valid completed visit', () => expect(validateVisit(base, { now: NOW }).valid).toBe(true));
  test('completed visit needs outcome, notes and a non-future date', () => {
    const r = validateVisit({ ...base, outcome: '', notes: 'short', date: '2026-12-01' }, { now: NOW });
    expect(r.errors).toEqual(expect.objectContaining({ outcome: expect.any(String), notes: expect.any(String), date: expect.any(String) }));
  });
  test('scheduled visits may be in the future but not the past when new', () => {
    const s = { beneficiaryId: 'b1', chwId: 'c1', status: 'scheduled', date: '2026-10-20' };
    expect(validateVisit(s, { isNew: true, now: NOW }).valid).toBe(true);
    expect(validateVisit({ ...s, date: '2026-10-01' }, { isNew: true, now: NOW }).errors.date).toBeDefined();
  });
});

describe('validateReferral', () => {
  const base = { beneficiaryId: 'b1', chwId: 'c1', facility: 'Prince Mshiyeni Hospital', reason: 'Suspected TB - persistent cough', urgency: 'urgent', referralDate: '2026-10-14', status: 'pending' };
  test('valid referral', () => expect(validateReferral(base, { now: NOW }).valid).toBe(true));
  test('completed referral requires outcome notes', () => {
    expect(validateReferral({ ...base, status: 'completed' }, { now: NOW }).errors.outcomeNotes).toBeDefined();
    expect(validateReferral({ ...base, status: 'completed', outcomeNotes: 'Treatment started' }, { now: NOW }).valid).toBe(true);
  });
  test('rejects unknown urgency and future referral date', () => {
    const r = validateReferral({ ...base, urgency: 'asap', referralDate: '2027-01-01' }, { now: NOW });
    expect(r.errors.urgency).toBeDefined();
    expect(r.errors.referralDate).toBeDefined();
  });
});

describe('validateAppointment', () => {
  const base = { beneficiaryId: 'b1', chwId: 'c1', datetime: '2026-10-20T09:00', purpose: 'ANC check-up', status: 'booked', reminderChannel: 'sms' };
  test('valid booking sets reminder due 24h before', () => {
    const r = validateAppointment(base, { now: NOW });
    expect(r.valid).toBe(true);
    expect(r.data.reminderDue).toBe('2026-10-19T09:00');
  });
  test('rejects past bookings but allows past attended records', () => {
    expect(validateAppointment({ ...base, datetime: '2026-10-01T09:00' }, { now: NOW }).errors.datetime).toBeDefined();
    expect(validateAppointment({ ...base, datetime: '2026-10-01T09:00', status: 'attended' }, { now: NOW }).valid).toBe(true);
  });
  test('no reminder when channel is none', () => {
    expect(validateAppointment({ ...base, reminderChannel: 'none' }, { now: NOW }).data.reminderDue).toBe('');
  });
});

describe('role-based access control matrix', () => {
  test('admin can do everything', () => {
    for (const c of ['beneficiaries', 'users', 'auditLogs', 'reports']) expect(can('admin', 'delete', c)).toBe(true);
    expect(can('admin', 'approve', 'reports')).toBe(true);
  });
  test('coordinator manages programme data but not users, audit or approvals', () => {
    expect(can('coordinator', 'update', 'visits')).toBe(true);
    expect(can('coordinator', 'delete', 'beneficiaries')).toBe(false);
    expect(can('coordinator', 'read', 'users')).toBe(false);
    expect(can('coordinator', 'approve', 'reports')).toBe(false);
    expect(can('coordinator', 'create', 'reports')).toBe(true);
  });
  test('CHW has no access to reports, users or audit logs', () => {
    expect(can('chw', 'create', 'visits')).toBe(true);
    expect(can('chw', 'read', 'reports')).toBe(false);
    expect(can('chw', 'read', 'users')).toBe(false);
    expect(can('chw', 'delete', 'beneficiaries')).toBe(false);
  });
  test('unknown role is denied', () => expect(can('guest', 'read', 'visits')).toBe(false));
});

describe('reporting', () => {
  const data = {
    beneficiaries: [{ enrolmentDate: '2026-09-05', programme: 'HIV/TB' }, { enrolmentDate: '2026-06-01', programme: 'Child Health' }],
    visits: [
      { date: '2026-09-10', status: 'completed', chwId: 'c1', outcome: 'Stable - no action needed' },
      { date: '2026-09-12', status: 'completed', chwId: 'c1', outcome: 'Referred to facility' },
      { date: '2026-09-15', status: 'scheduled', chwId: 'c2' },
      { date: '2026-01-15', status: 'completed', chwId: 'c2', outcome: 'Stable - no action needed' }
    ],
    referrals: [{ referralDate: '2026-09-12', status: 'completed' }, { referralDate: '2026-09-20', status: 'pending' }],
    appointments: [{ datetime: '2026-09-25T10:00', status: 'attended' }, { datetime: '2026-09-26T10:00', status: 'missed' }]
  };
  const s = summariseActivity(data, '2026-09-01', '2026-09-30', { c1: 'Thandi' });
  test('counts only items inside the date range', () => {
    expect(s.newBeneficiaries).toBe(1);
    expect(s.visitsTotal).toBe(3);
    expect(s.visitsCompleted).toBe(2);
    expect(s.visitsPerChw).toEqual({ Thandi: 2 });
  });
  test('computes rates', () => {
    expect(s.referralCompletionRate).toBe(50);
    expect(s.appointmentAttendanceRate).toBe(50);
  });
  test('empty data does not divide by zero', () => {
    expect(summariseActivity({}, '2026-01-01', '2026-01-31').referralCompletionRate).toBe(0);
  });
  test('toCSV escapes commas, quotes and formula injection', () => {
    const csv = toCSV([['A, B', 'say "hi"', '=SUM(A1)']], ['x', 'y', 'z']);
    expect(csv).toBe('x,y,z\r\n"A, B","say ""hi""",\'=SUM(A1)');
  });
  test('matchesSearch is multi-term and case-insensitive', () => {
    expect(matchesSearch('Nomsa Dlamini Umlazi', 'nomsa umlazi')).toBe(true);
    expect(matchesSearch('Nomsa Dlamini', 'zulu')).toBe(false);
    expect(matchesSearch('anything', '')).toBe(true);
  });
});
