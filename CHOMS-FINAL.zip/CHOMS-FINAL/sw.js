/* Service worker: caches the app shell so CHOMS opens with no signal. Data caching is handled in js/repo.js. */
const CACHE = 'choms-shell-v1';
const SHELL = ['./', 'index.html', 'css/style.css', 'js/app.js', 'js/utils.js', 'js/repo.js', 'js/ui.js', 'js/entities.js',
  'js/firebase.js', 'js/firebase-config.js', 'manifest.json', 'icon.svg'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

// Network-first for our own files (always get updates when online), cache fallback when offline.
// Firebase SDK scripts from gstatic are cached on first use so the app also boots offline.
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  const ours = url.origin === self.location.origin;
  const sdk = url.hostname === 'www.gstatic.com' && url.pathname.includes('/firebasejs/');
  if (!ours && !sdk) return; // Firestore / Auth API calls are never intercepted
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
        return res;
      })
      .catch(() => caches.match(e.request).then((hit) => hit || (e.request.mode === 'navigate' ? caches.match('index.html') : Response.error())))
  );
});
