/**
 * app.js - application controller: authentication, routing, views and event handling.
 * (Presentation layer; talks to repo.js for data and utils.js for business rules.)
 */
import {
  configured, auth, db, onAuthStateChanged, signInWithEmailAndPassword, signOut, sendPasswordResetEmail,
  doc, getDoc, createAuthUser
} from './firebase.js';
import * as repo from './repo.js';
import { buildEntities } from './entities.js';
import { $, $$, toast, openModal, confirmDialog, formHTML, readForm, showFormErrors, badge, friendlyError, downloadFile } from './ui.js';
import {
  can, escapeHtml as esc, todayISO, addDays, formatDate, formatDateTime, calcAge, maskId, generateRef, isValidEmail,
  validatePassword, sanitizeText, summariseActivity, toCSV, matchesSearch, ROLES, normalisePhone, isFutureDateTime
} from './utils.js';

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */
const S = {
  uid: null, role: null, profile: null, users: [],
  data: { beneficiaries: [], visits: [], referrals: [], appointments: [], reports: [], auditLogs: [] },
  route: 'dashboard', search: {}, filter: {}, report: { from: '', to: '', summary: null }
};
let ENT = buildEntities(S);
const isStaff = () => S.role === 'admin' || S.role === 'coordinator';
const ROLE_LABEL = { admin: 'Administrator', coordinator: 'Programme Coordinator', chw: 'Community Health Worker' };

const ICONS = {
  dashboard: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  beneficiaries: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.2c2.2.6 3.5 2.5 3.5 5.8"/>',
  visits: '<path d="M9 4h6v3H9z"/><path d="M7 5H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2"/><path d="M8 12h8M8 16h5"/>',
  referrals: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  appointments: '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  reports: '<path d="M4 20V4M4 20h16"/><path d="M8 16v-5M12 16V8M16 16v-8"/>',
  users: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  audit: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>'
};
const icon = (n) => `<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

const NAV = [
  { id: 'dashboard', label: 'Dashboard', roles: ROLES },
  { id: 'beneficiaries', label: () => ENT.beneficiaries.title, roles: ROLES },
  { id: 'visits', label: () => (isStaff() ? 'Visits' : 'My Visits'), roles: ROLES },
  { id: 'referrals', label: 'Referrals', roles: ROLES },
  { id: 'appointments', label: 'Appointments', roles: ROLES },
  { id: 'reports', label: 'Reports', roles: ['admin', 'coordinator'] },
  { id: 'users', label: 'Users', roles: ['admin'] },
  { id: 'audit', label: 'Audit log', roles: ['admin'] }
];
const navItems = () => NAV.filter((n) => n.roles.includes(S.role));
const navLabel = (n) => (typeof n.label === 'function' ? n.label() : n.label);

/* ------------------------------------------------------------------ */
/* Bootstrap                                                           */
/* ------------------------------------------------------------------ */
function init() {
  window.addEventListener('unhandledrejection', (e) => { console.error(e.reason); toast(friendlyError(e.reason), 'error'); });
  window.addEventListener('error', (e) => console.error(e.error || e.message));
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW registration failed', e));

  if (!configured) {
    $('#login-view').hidden = true;
    $('#setup-banner').hidden = false;
    return;
  }
  wireLogin();
  onAuthStateChanged(auth, async (user) => {
    try {
      if (user) await startSession(user);
      else showLogin();
    } catch (e) {
      console.error(e);
      toast(friendlyError(e), 'error', 8000);
      showLogin();
    }
  });
  window.addEventListener('online', onOnline);
  window.addEventListener('offline', updateSyncChip);
  window.addEventListener('hashchange', () => S.uid && renderRoute());
  repo.onSyncChange(updateSyncChip);
  setInterval(() => { if (S.uid && navigator.onLine && repo.pendingCount()) repo.flush(); }, 60000);
}

function showLogin() {
  S.uid = null;
  $('#app').hidden = true;
  $('#login-view').hidden = false;
  document.body.classList.remove('role-chw');
}

const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(Object.assign(new Error('Request timed out'), { code: 'timeout' })), ms))]);

async function startSession(user) {
  let profile = null;
  try {
    const snap = await withTimeout(getDoc(doc(db, 'users', user.uid)), 10000);
    profile = snap.exists() ? { id: snap.id, ...snap.data() } : null;
    if (profile) repo.cacheProfile(user.uid, profile);
  } catch (e) {
    if (['unavailable', 'timeout'].includes(e.code) || !navigator.onLine) profile = repo.cachedProfile(user.uid);
    else throw e;
  }
  if (!profile || !ROLES.includes(profile.role)) {
    await signOut(auth);
    throw new Error('Your account has no CHOMS profile. Please contact your administrator.');
  }
  if (profile.active === false) {
    await signOut(auth);
    throw new Error('Your account has been deactivated. Please contact your administrator.');
  }
  Object.assign(S, { uid: user.uid, role: profile.role, profile, route: 'dashboard' });
  repo.setContext({ uid: user.uid, role: profile.role, name: profile.name });
  ENT = buildEntities(S);

  $('#login-view').hidden = true;
  $('#app').hidden = false;
  document.body.classList.toggle('role-chw', S.role === 'chw');
  $('#user-name').textContent = profile.name;
  $('#user-role').textContent = ROLE_LABEL[profile.role];
  $('#user-avatar').textContent = (profile.name || '?').trim().charAt(0).toUpperCase();
  buildNav();
  updateSyncChip();
  $('#view').innerHTML = '<div class="loading">Loading your data...</div>';
  await loadAll();
  if (!location.hash) location.hash = '#/dashboard';
  renderRoute();
}

async function loadAll() {
  if (navigator.onLine) await repo.flush().catch(() => {});
  const cols = ['beneficiaries', 'visits', 'referrals', 'appointments', ...(isStaff() ? ['reports'] : [])];
  const jobs = cols.map((c) => repo.list(c));
  if (isStaff()) jobs.push(repo.list('users'));
  const res = await Promise.allSettled(jobs);
  res.forEach((r, i) => {
    const name = i < cols.length ? cols[i] : 'users';
    if (r.status === 'fulfilled') {
      if (name === 'users') S.users = r.value;
      else S.data[name] = r.value;
    } else toast(`Could not load ${name}: ${friendlyError(r.reason)}`, 'error');
  });
  if (!isStaff()) S.users = [];
  ENT = buildEntities(S);
}

async function onOnline() {
  updateSyncChip();
  if (!S.uid) return;
  toast('Back online - syncing...', 'info', 2500);
  const r = await repo.flush();
  reportSyncResult(r);
  await refreshView();
}

function reportSyncResult(r) {
  if (r.synced) toast(`${r.synced} change${r.synced > 1 ? 's' : ''} synced to the cloud.`, 'success');
  if (r.failed.length) toast(`${r.failed.length} change(s) were rejected by the server (permissions). Contact your administrator.`, 'error', 8000);
}

async function refreshView() {
  await loadAll();
  if (!$('.modal-overlay')) renderRoute();
}

/* ------------------------------------------------------------------ */
/* Login                                                               */
/* ------------------------------------------------------------------ */
let failedLogins = 0;
let lockedUntil = 0;

function wireLogin() {
  const form = $('#login-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('#login-error');
    err.textContent = '';
    const email = form.email.value.trim();
    const password = form.password.value;
    if (Date.now() < lockedUntil) {
      err.textContent = `Too many failed attempts. Try again in ${Math.ceil((lockedUntil - Date.now()) / 1000)}s.`;
      return;
    }
    if (!isValidEmail(email)) { err.textContent = 'Enter a valid email address.'; form.email.focus(); return; }
    if (!password) { err.textContent = 'Enter your password.'; form.password.focus(); return; }
    const btn = $('button[type=submit]', form);
    btn.disabled = true;
    btn.textContent = 'Signing in...';
    try {
      await signInWithEmailAndPassword(auth, email, password);
      failedLogins = 0;
      form.password.value = '';
    } catch (ex) {
      console.warn('Login failed', ex.code);
      if (++failedLogins >= 5) { lockedUntil = Date.now() + 60000; failedLogins = 0; }
      err.textContent = friendlyError(ex);
    } finally {
      btn.disabled = false;
      btn.textContent = 'Sign in';
    }
  });
  $('#forgot-link').addEventListener('click', async (e) => {
    e.preventDefault();
    const email = form.email.value.trim();
    const err = $('#login-error');
    if (!isValidEmail(email)) { err.textContent = 'Enter your email above first, then click "Forgot password".'; return; }
    try {
      await sendPasswordResetEmail(auth, email);
      err.textContent = '';
      toast('If that account exists, a password reset email has been sent.', 'success', 7000);
    } catch (ex) {
      err.textContent = friendlyError(ex);
    }
  });
}

async function logout() {
  if (repo.pendingCount() && navigator.onLine) reportSyncResult(await repo.flush());
  const n = repo.pendingCount();
  if (n) {
    const ok = await confirmDialog(`${n} change${n > 1 ? 's have' : ' has'} not synced yet. They stay saved on this device and will sync next time you sign in here. Sign out anyway?`, { confirmText: 'Sign out', danger: true });
    if (!ok) return;
  } else repo.wipeLocalData(); // POPIA: do not leave client data on a shared phone
  await signOut(auth);
  location.hash = '';
}

/* ------------------------------------------------------------------ */
/* Shell: navigation + sync chip                                       */
/* ------------------------------------------------------------------ */
function buildNav() {
  const items = navItems();
  $('#nav').innerHTML = items.map((n) => `<a href="#/${n.id}" data-route="${n.id}">${icon(n.id)}<span>${esc(navLabel(n))}</span></a>`).join('');
  $('#tabbar').innerHTML = items.slice(0, 5).map((n) => `<a href="#/${n.id}" data-route="${n.id}">${icon(n.id)}<span>${esc(navLabel(n).replace('My ', ''))}</span></a>`).join('');
}

function updateSyncChip() {
  const chip = $('#sync-chip');
  if (!chip) return;
  const online = navigator.onLine;
  const n = repo.pendingCount();
  chip.className = `chip ${online ? (n ? 'chip-warn' : 'chip-ok') : 'chip-off'}`;
  chip.textContent = `${online ? 'Online' : 'Offline'} · ${n ? `${n} pending` : 'all synced'}`;
  $('#sync-btn').disabled = !online || !n;
  document.body.classList.toggle('is-offline', !online);
}

/* ------------------------------------------------------------------ */
/* Router                                                              */
/* ------------------------------------------------------------------ */
async function renderRoute() {
  let id = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('?')[0];
  if (!navItems().some((n) => n.id === id)) id = 'dashboard';
  S.route = id;
  $$('[data-route]').forEach((a) => a.classList.toggle('active', a.dataset.route === id));
  const nav = navItems().find((n) => n.id === id);
  $('#page-title').textContent = navLabel(nav);
  document.title = `${navLabel(nav)} | MatCH CHOMS`;
  $('#sidebar').classList.remove('open');
  try {
    if (id === 'dashboard') renderDashboard();
    else if (ENT[id]) renderEntity(id);
    else if (id === 'reports') renderReports();
    else if (id === 'users') await renderUsers();
    else if (id === 'audit') await renderAudit();
  } catch (e) {
    console.error(e);
    $('#view').innerHTML = `<div class="empty"><h3>Something went wrong</h3><p>${esc(friendlyError(e))}</p></div>`;
  }
}

/* ------------------------------------------------------------------ */
/* Dashboard                                                           */
/* ------------------------------------------------------------------ */
const stat = (label, value, sub = '', go = '') =>
  `<${go ? `a href="#/${go}"` : 'div'} class="stat"><div class="stat-val">${value}</div><div class="stat-label">${esc(label)}</div>${sub ? `<div class="stat-sub">${esc(sub)}</div>` : ''}</${go ? 'a' : 'div'}>`;

function renderDashboard() {
  const { beneficiaries: B, visits: V, referrals: R, appointments: A } = S.data;
  const today = todayISO();
  const monthStart = `${today.slice(0, 8)}01`;
  const nowDT = `${today}T00:00`;
  const nextWeek = addDays(today, 7);
  const openRef = R.filter((r) => r.status === 'pending');
  const upcomingAppts = A.filter((a) => ['booked', 'rescheduled'].includes(a.status) && a.datetime >= nowDT).sort((a, b) => a.datetime.localeCompare(b.datetime));
  const scheduled = V.filter((v) => v.status === 'scheduled').sort((a, b) => a.date.localeCompare(b.date));
  const doneThisMonth = V.filter((v) => v.status === 'completed' && v.date >= monthStart).length;
  const overdue = scheduled.filter((v) => v.date < today).length;

  const stats = isStaff()
    ? [
        stat('Active beneficiaries', B.filter((b) => b.status === 'active').length, `${B.length} registered in total`, 'beneficiaries'),
        stat('Visits this month', doneThisMonth, `${scheduled.length} scheduled`, 'visits'),
        stat('Pending referrals', openRef.length, `${openRef.filter((r) => r.urgency !== 'routine').length} urgent / emergency`, 'referrals'),
        stat('Upcoming appointments', upcomingAppts.length, `${A.filter((a) => a.status === 'missed').length} missed to date`, 'appointments')
      ]
    : [
        stat('My clients', B.filter((b) => b.status === 'active').length, '', 'beneficiaries'),
        stat('Visits to do', scheduled.length, overdue ? `${overdue} overdue` : 'none overdue', 'visits'),
        stat('Pending referrals', openRef.length, '', 'referrals'),
        stat('Upcoming appointments', upcomingAppts.length, '', 'appointments')
      ];

  const rowList = (items, fn, empty) => (items.length ? `<ul class="list">${items.map(fn).join('')}</ul>` : `<p class="muted pad">${empty}</p>`);
  const toDo = rowList(
    scheduled.filter((v) => v.date <= nextWeek).slice(0, 6),
    (v) => `<li><div><strong>${esc(ENT.helpers.benName(v.beneficiaryId))}</strong><small>${formatDate(v.date)}${v.date < today ? ' · overdue' : ''}${isStaff() ? ` · ${esc(ENT.helpers.chwName(v.chwId))}` : ''}</small></div>
      <button class="btn btn-sm btn-primary" data-action="complete-visit" data-id="${v.id}">Complete</button></li>`,
    'No visits scheduled in the next 7 days.'
  );
  const appts = rowList(upcomingAppts.slice(0, 6), (a) => `<li><div><strong>${esc(ENT.helpers.benName(a.beneficiaryId))}</strong><small>${formatDateTime(a.datetime)} · ${esc(a.purpose)}</small></div>${badge(a.status)}</li>`, 'No upcoming appointments.');
  const urgent = rowList(
    openRef.sort((a, b) => (a.urgency === 'routine') - (b.urgency === 'routine')).slice(0, 6),
    (r) => `<li><div><strong>${esc(ENT.helpers.benName(r.beneficiaryId))}</strong><small>${esc(r.facility)} · ${formatDate(r.referralDate)}</small></div>${badge(r.urgency)}</li>`,
    'No pending referrals.'
  );

  let chart = '';
  if (isStaff()) {
    const counts = {};
    V.filter((v) => v.status === 'completed' && v.date >= monthStart).forEach((v) => { const n = ENT.helpers.chwName(v.chwId); counts[n] = (counts[n] || 0) + 1; });
    const max = Math.max(1, ...Object.values(counts));
    const rows = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    chart = `<section class="card"><h3>Completed visits per CHW (this month)</h3>${
      rows.length ? rows.map(([n, c]) => `<div class="bar-row"><span class="bar-label">${esc(n)}</span><div class="bar"><i style="width:${(c / max) * 100}%"></i></div><b>${c}</b></div>`).join('') : '<p class="muted">No completed visits yet this month.</p>'
    }</section>`;
  }

  $('#view').innerHTML = `
    <div class="welcome"><div><h2>Hello, ${esc((S.profile.name || '').split(' ')[0])}</h2><p class="muted">${esc(ROLE_LABEL[S.role])} · ${formatDate(today)}</p></div>
      <div class="quick">
        ${can(S.role, 'create', 'visits') ? '<button class="btn btn-primary" data-action="add" data-entity="visits">+ Record visit</button>' : ''}
        <button class="btn" data-action="add" data-entity="referrals">+ Referral</button>
        <button class="btn" data-action="add" data-entity="beneficiaries">+ ${isStaff() ? 'Beneficiary' : 'Client'}</button>
      </div></div>
    <div class="stats">${stats.join('')}</div>
    <div class="grid-2">
      <section class="card"><h3>Visits to do (next 7 days)</h3>${toDo}</section>
      <section class="card"><h3>Upcoming appointments</h3>${appts}</section>
      <section class="card"><h3>Pending referrals</h3>${urgent}</section>
      ${chart}
    </div>`;
}

/* ------------------------------------------------------------------ */
/* Generic entity list + form                                          */
/* ------------------------------------------------------------------ */
function renderEntity(key) {
  const E = ENT[key];
  const canCreate = can(S.role, 'create', E.col);
  const search = S.search[key] || '';
  const filter = S.filter[key] || '';
  $('#view').innerHTML = `
    <div class="toolbar">
      <input type="search" class="search" data-search="${key}" placeholder="Search ${esc(E.plural.toLowerCase())}..." value="${esc(search)}" aria-label="Search"/>
      <select data-filter="${key}" aria-label="Filter by status"><option value="">All statuses</option>${E.statuses.map((s) => `<option ${filter === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
      <span class="spacer"></span>
      ${canCreate && key === 'visits' && isStaff() ? '<button class="btn" data-action="schedule-visit">Schedule visit</button>' : ''}
      ${canCreate ? `<button class="btn btn-primary" data-action="add" data-entity="${key}">+ ${esc(E.addLabel)}</button>` : ''}
    </div>
    <div class="table-wrap" id="tbl"></div>`;
  paintTable(key);
}

function paintTable(key) {
  const E = ENT[key];
  const term = S.search[key] || '';
  const status = S.filter[key] || '';
  const rows = S.data[E.col].filter((r) => (!status || r.status === status) && matchesSearch(E.searchText(r), term)).sort(E.sort);
  const tbl = $('#tbl');
  if (!rows.length) {
    tbl.innerHTML = `<div class="empty"><h3>${S.data[E.col].length ? 'No matches' : `No ${E.plural.toLowerCase()} yet`}</h3><p>${S.data[E.col].length ? 'Try a different search or filter.' : can(S.role, 'create', E.col) ? `Use the "${esc(E.addLabel)}" button to add the first one.` : 'Nothing to show.'}</p></div>`;
    return;
  }
  tbl.innerHTML = `<table class="table"><thead><tr>${E.columns.map((c) => `<th>${esc(c.label)}</th>`).join('')}<th class="actions-col"><span class="sr-only">Actions</span></th></tr></thead>
    <tbody>${rows.map((r) => `<tr>${E.columns.map((c) => `<td data-label="${esc(c.label)}">${c.render(r)}</td>`).join('')}<td class="row-actions">${rowActions(key, r)}</td></tr>`).join('')}</tbody></table>
    <div class="muted count">${rows.length} of ${S.data[E.col].length}</div>`;
}

function rowActions(key, r) {
  const b = [];
  const attr = `data-entity="${key}" data-id="${r.id}"`;
  if (key === 'beneficiaries') b.push(`<button class="btn btn-sm" data-action="view-case" data-id="${r.id}">Case file</button>`);
  if (key === 'visits' && r.status === 'scheduled' && can(S.role, 'update', 'visits')) b.push(`<button class="btn btn-sm btn-primary" data-action="complete-visit" data-id="${r.id}">Complete</button>`);
  if (key === 'appointments' && ['booked', 'rescheduled'].includes(r.status) && can(S.role, 'update', 'appointments')) b.push(`<button class="btn btn-sm" data-action="cancel-appt" data-id="${r.id}">Cancel</button>`);
  if (can(S.role, 'update', ENT[key].col)) b.push(`<button class="btn btn-sm" data-action="edit" ${attr}>${key === 'appointments' ? 'Reschedule / edit' : 'Edit'}</button>`);
  if (can(S.role, 'delete', ENT[key].col)) b.push(`<button class="btn btn-sm btn-danger-ghost" data-action="delete" ${attr}>Delete</button>`);
  return b.join('');
}

function openEntityForm(key, id = null, preset = {}) {
  const E = ENT[key];
  const existing = id ? S.data[E.col].find((r) => r.id === id) : null;
  if (id && !existing) return toast('That record no longer exists.', 'error');
  if (!id && ['visits', 'referrals', 'appointments'].includes(key) && !S.data.beneficiaries.some((b) => b.status !== 'closed')) {
    return toast('Register a beneficiary first - there is nobody to link this record to.', 'error');
  }
  const fields = E.fields().filter((f) => !f.hidden);
  const values = existing ? { ...existing } : { ...E.defaults(), ...preset };
  const m = openModal({
    title: `${id ? 'Edit' : 'New'} ${E.singular}`,
    wide: true,
    body: `<form id="ent-form" novalidate>${formHTML(fields, values)}<div class="form-error" id="form-error" role="alert"></div></form>`,
    footer: '<button type="button" class="btn" data-close>Cancel</button><button type="submit" class="btn btn-primary" form="ent-form" id="save-btn">Save</button>'
  });
  const form = $('#ent-form', m.el);
  E.afterRender?.(form);
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    $('#form-error', form).textContent = '';
    const raw = { ...(existing || {}), ...readForm(form, fields) };
    if (isChwRole()) { raw.chwId = S.uid; raw.assignedChwId = S.uid; }
    const dateChanged = !existing || existing.datetime !== raw.datetime;
    const res = E.validate(raw, { isNew: !id, id, dateChanged });
    showFormErrors(form, res.errors);
    if (!res.valid) { $('#form-error', form).textContent = 'Please fix the highlighted fields.'; return; }
    const btn = $('#save-btn', m.el);
    btn.disabled = true;
    btn.textContent = 'Saving...';
    try {
      let data = E.prepare ? E.prepare(res.data, existing) : res.data;
      const docId = id || repo.newId(E.col);
      if (!id && E.afterCreate) data = { ...data, ...E.afterCreate(docId, data) };
      await repo.save(E.col, docId, data, { isNew: !id, summary: E.summary(data) });
      S.data[E.col] = await repo.list(E.col);
      m.close();
      toast(navigator.onLine && !repo.pendingCount() ? `${cap(E.singular)} saved.` : `${cap(E.singular)} saved on this device - it will sync when you are online.`, 'success');
      updateSyncChip();
      renderRoute();
    } catch (ex) {
      console.error(ex);
      $('#form-error', form).textContent = friendlyError(ex);
      btn.disabled = false;
      btn.textContent = 'Save';
    }
  });
}
const isChwRole = () => S.role === 'chw';
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

async function deleteRecord(key, id) {
  const E = ENT[key];
  const r = S.data[E.col].find((x) => x.id === id);
  if (!r) return;
  if (!(await confirmDialog(`Delete this ${E.singular}? This cannot be undone.`, { confirmText: 'Delete', danger: true }))) return;
  try {
    await repo.remove(E.col, id, { summary: E.summary(r) });
    S.data[E.col] = await repo.list(E.col);
    toast(`${cap(E.singular)} deleted.`, 'success');
    updateSyncChip();
    renderRoute();
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

async function patchRecord(key, id, patch, okMsg) {
  const E = ENT[key];
  const r = S.data[E.col].find((x) => x.id === id);
  if (!r) return;
  try {
    await repo.save(E.col, id, { ...patch }, { isNew: false, summary: `${E.summary({ ...r, ...patch })}` });
    S.data[E.col] = await repo.list(E.col);
    toast(okMsg, 'success');
    updateSyncChip();
    renderRoute();
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

/* ------------------------------------------------------------------ */
/* Case file (FR2 / FR9)                                               */
/* ------------------------------------------------------------------ */
function openCase(id) {
  const b = S.data.beneficiaries.find((x) => x.id === id);
  if (!b) return;
  const H = ENT.helpers;
  const hist = (arr, dateKey, line) =>
    arr.filter((x) => x.beneficiaryId === id).sort((a, c) => String(c[dateKey]).localeCompare(String(a[dateKey]))).map(line).join('') || '<li class="muted">None recorded.</li>';
  const age = calcAge(b.dob);
  const m = openModal({
    title: `Case file - ${b.firstName} ${b.lastName}`,
    wide: true,
    body: `
      <dl class="kv">
        <div><dt>Reference</dt><dd>${esc(b.ref || generateRef(b.id))}</dd></div><div><dt>ID number</dt><dd>${esc(maskId(b.idNumber))}</dd></div>
        <div><dt>Age / gender</dt><dd>${age ?? '-'} · ${esc(b.gender)}</dd></div><div><dt>Cell</dt><dd>${b.phone ? `<a href="tel:${esc(b.phone)}">${esc(b.phone)}</a>` : '-'}</dd></div>
        <div><dt>Programme</dt><dd>${esc(b.programme)}</dd></div><div><dt>Area</dt><dd>${esc(b.area)}${b.address ? `, ${esc(b.address)}` : ''}</dd></div>
        <div><dt>Assigned CHW</dt><dd>${esc(H.chwName(b.assignedChwId))}</dd></div><div><dt>Enrolled</dt><dd>${formatDate(b.enrolmentDate)} ${badge(b.status)}</dd></div>
      </dl>
      <div class="case-cols">
        <section><h4>Visits</h4><ul class="timeline">${hist(S.data.visits, 'date', (v) => `<li><b>${formatDate(v.date)}</b> ${badge(v.status)}<br><small>${esc(v.outcome || '')}${v.notes ? ` - ${esc(v.notes)}` : ''}</small></li>`)}</ul></section>
        <section><h4>Referrals</h4><ul class="timeline">${hist(S.data.referrals, 'referralDate', (r) => `<li><b>${formatDate(r.referralDate)}</b> ${badge(r.status)} ${badge(r.urgency)}<br><small>${esc(r.facility)} - ${esc(r.reason)}</small></li>`)}</ul></section>
        <section><h4>Appointments</h4><ul class="timeline">${hist(S.data.appointments, 'datetime', (a) => `<li><b>${formatDateTime(a.datetime)}</b> ${badge(a.status)}<br><small>${esc(a.purpose)}</small></li>`)}</ul></section>
      </div>`,
    footer: `<button class="btn" data-close>Close</button>
      <button class="btn" data-x="referrals">+ Referral</button><button class="btn" data-x="appointments">+ Appointment</button><button class="btn btn-primary" data-x="visits">+ Visit</button>`
  });
  $$('[data-x]', m.el).forEach((btn) => btn.addEventListener('click', () => {
    m.close();
    openEntityForm(btn.dataset.x, null, { beneficiaryId: id, chwId: b.assignedChwId });
  }));
}

/* ------------------------------------------------------------------ */
/* Reports (FR8)                                                       */
/* ------------------------------------------------------------------ */
function renderReports() {
  const today = todayISO();
  if (!S.report.from) { S.report.from = `${today.slice(0, 8)}01`; S.report.to = today; }
  const saved = [...S.data.reports].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  $('#view').innerHTML = `
    <section class="card no-print">
      <h3>Generate programme report</h3>
      <form id="report-form" class="inline-form" novalidate>
        <label>From <input type="date" name="from" value="${S.report.from}" required/></label>
        <label>To <input type="date" name="to" value="${S.report.to}" required/></label>
        <button class="btn btn-primary" type="submit">Generate</button>
      </form><div class="err" id="report-err" role="alert"></div>
    </section>
    <div id="report-out">${S.report.summary ? reportHTML(S.report.summary) : '<div class="empty"><p>Choose a date range and click Generate.</p></div>'}</div>
    <section class="card no-print"><h3>Saved reports</h3>
      ${saved.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>Period</th><th>Prepared by</th><th>Status</th><th></th></tr></thead><tbody>${saved
        .map((r) => `<tr><td data-label="Period">${formatDate(r.from)} - ${formatDate(r.to)}</td><td data-label="Prepared by">${esc(r.generatedBy || '-')}</td><td data-label="Status">${badge(r.status)}${r.approvedBy ? `<small class="muted"> by ${esc(r.approvedBy)}</small>` : ''}</td>
          <td class="row-actions"><button class="btn btn-sm" data-action="open-report" data-id="${r.id}">Open</button>
          ${can(S.role, 'approve', 'reports') && r.status !== 'approved' ? `<button class="btn btn-sm btn-primary" data-action="approve-report" data-id="${r.id}">Approve</button>` : ''}
          ${can(S.role, 'delete', 'reports') && (r.status !== 'approved' || S.role === 'admin') ? `<button class="btn btn-sm btn-danger-ghost" data-action="delete-report" data-id="${r.id}">Delete</button>` : ''}</td></tr>`)
        .join('')}</tbody></table></div>` : '<p class="muted">No saved reports yet.</p>'}
    </section>`;
  $('#report-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const f = e.target;
    const err = $('#report-err');
    err.textContent = '';
    if (!f.from.value || !f.to.value) { err.textContent = 'Both dates are required.'; return; }
    if (f.from.value > f.to.value) { err.textContent = '"From" must be on or before "To".'; return; }
    try {
      const names = Object.fromEntries(S.users.map((u) => [u.id, u.name]));
      S.report = { from: f.from.value, to: f.to.value, summary: summariseActivity(S.data, f.from.value, f.to.value, names) };
      $('#report-out').innerHTML = reportHTML(S.report.summary);
    } catch (ex) { console.error(ex); err.textContent = 'Could not generate the report.'; }
  });
}

const kvTable = (obj, title) => {
  const rows = Object.entries(obj || {});
  return `<table class="table mini"><thead><tr><th colspan="2">${esc(title)}</th></tr></thead><tbody>${rows.length ? rows.map(([k, v]) => `<tr><td>${esc(k)}</td><td class="num">${v}</td></tr>`).join('') : '<tr><td class="muted" colspan="2">No data</td></tr>'}</tbody></table>`;
};

function reportHTML(s, meta = {}) {
  return `<section class="card report"><div class="report-head"><div><h3>Programme report: ${formatDate(s.from)} to ${formatDate(s.to)}</h3>
    <p class="muted">MatCH Community Health &amp; Outreach Management System${meta.status ? ` · ${esc(meta.status)}` : ''}</p></div>
    <div class="no-print">${meta.saved ? '' : '<button class="btn btn-primary" data-action="save-report">Save for approval</button>'}
    <button class="btn" data-action="export-report">Export CSV</button><button class="btn" data-action="print-report">Print / PDF</button></div></div>
    <div class="stats">${stat('New beneficiaries', s.newBeneficiaries)}${stat('Visits completed', s.visitsCompleted, `${s.visitsTotal} total`)}${stat('Referrals', s.referralsTotal, `${s.referralCompletionRate}% attended / completed`)}${stat('Appointments', s.appointmentsTotal, `${s.appointmentAttendanceRate}% attended`)}</div>
    <div class="grid-3">${kvTable(s.beneficiariesByProgramme, 'New beneficiaries by programme')}${kvTable(s.visitsByOutcome, 'Visit outcomes')}${kvTable(s.visitsPerChw, 'Completed visits per CHW')}${kvTable(s.referralsByStatus, 'Referrals by status')}${kvTable(s.appointmentsByStatus, 'Appointments by status')}</div></section>`;
}

function reportCSV(s) {
  const rows = [
    ['Period', `${s.from} to ${s.to}`], ['New beneficiaries', s.newBeneficiaries], ['Visits total', s.visitsTotal], ['Visits completed', s.visitsCompleted],
    ['Referrals total', s.referralsTotal], ['Referral completion rate %', s.referralCompletionRate], ['Appointments total', s.appointmentsTotal], ['Appointment attendance rate %', s.appointmentAttendanceRate]
  ];
  const add = (title, obj) => Object.entries(obj).forEach(([k, v]) => rows.push([`${title}: ${k}`, v]));
  add('Programme', s.beneficiariesByProgramme); add('Outcome', s.visitsOutcome || s.visitsByOutcome); add('CHW visits', s.visitsPerChw);
  add('Referral status', s.referralsByStatus); add('Appointment status', s.appointmentsByStatus);
  return toCSV(rows, ['Measure', 'Value']);
}

async function saveReport() {
  const s = S.report.summary;
  if (!s) return;
  try {
    await repo.save('reports', null, { from: s.from, to: s.to, summaryJson: JSON.stringify(s), status: 'pending', generatedBy: S.profile.name }, { summary: `Report ${s.from} to ${s.to}` });
    S.data.reports = await repo.list('reports');
    toast('Report saved and awaiting approval.', 'success');
    renderReports();
  } catch (e) { toast(friendlyError(e), 'error'); }
}

/* ------------------------------------------------------------------ */
/* Users (FR7 / FR11) - admin only                                     */
/* ------------------------------------------------------------------ */
async function renderUsers() {
  try { S.users = await repo.list('users'); } catch (e) { toast(friendlyError(e), 'error'); }
  ENT = buildEntities(S);
  const rows = [...S.users].sort((a, b) => String(a.name).localeCompare(String(b.name)));
  $('#view').innerHTML = `<div class="toolbar"><span class="muted">${rows.length} account${rows.length === 1 ? '' : 's'}</span><span class="spacer"></span><button class="btn btn-primary" data-action="add-user">+ Add user</button></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody>
    ${rows.map((u) => `<tr><td data-label="Name"><strong>${esc(u.name)}</strong></td><td data-label="Email">${esc(u.email)}</td><td data-label="Role">${esc(ROLE_LABEL[u.role] || u.role)}</td>
      <td data-label="Status">${badge(u.active === false ? 'closed' : 'active').replace('>closed<', '>deactivated<')}</td>
      <td class="row-actions"><button class="btn btn-sm" data-action="edit-user" data-id="${u.id}">Edit</button>
      ${u.id !== S.uid ? `<button class="btn btn-sm ${u.active === false ? '' : 'btn-danger-ghost'}" data-action="toggle-user" data-id="${u.id}">${u.active === false ? 'Reactivate' : 'Deactivate'}</button>` : ''}</td></tr>`).join('')}
    </tbody></table></div>`;
}

function openUserForm(id = null) {
  const u = id ? S.users.find((x) => x.id === id) : null;
  const fields = [
    { name: 'name', label: 'Full name', required: true, maxlength: 80 },
    { name: 'email', label: 'Email', type: 'email', required: true, maxlength: 120, readonly: !!u },
    { name: 'role', label: 'Role', type: 'select', required: true, options: ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] })) },
    ...(u ? [] : [{ name: 'password', label: 'Temporary password', type: 'password', required: true, maxlength: 64, help: 'Min 8 characters with upper-case, lower-case and a number. Ask the user to change it after first sign-in.', autocomplete: 'new-password' }])
  ];
  const m = openModal({
    title: u ? 'Edit user' : 'Add user', body: `<form id="user-form" novalidate>${formHTML(fields, u || { role: 'chw' })}<div class="form-error" id="form-error" role="alert"></div></form>`,
    footer: '<button type="button" class="btn" data-close>Cancel</button><button type="submit" class="btn btn-primary" form="user-form" id="save-btn">Save</button>'
  });
  const form = $('#user-form', m.el);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const raw = readForm(form, fields);
    const errors = {};
    const name = sanitizeText(raw.name, 80);
    const email = String(raw.email || '').trim().toLowerCase();
    if (name.length < 3) errors.name = 'Enter the full name.';
    if (!isValidEmail(email)) errors.email = 'Enter a valid email address.';
    if (!ROLES.includes(raw.role)) errors.role = 'Select a role.';
    if (u && u.id === S.uid && raw.role !== 'admin') errors.role = 'You cannot remove your own administrator role.';
    if (!u) { const pe = validatePassword(raw.password); if (pe) errors.password = pe; }
    showFormErrors(form, errors);
    if (Object.keys(errors).length) return;
    const btn = $('#save-btn', m.el);
    btn.disabled = true;
    try {
      if (u) {
        await repo.saveOnline('users', u.id, { name, role: raw.role }, `Updated user ${name} (${raw.role})`);
      } else {
        const uid = await createAuthUser(email, raw.password);
        try {
          await repo.saveOnline('users', uid, { name, email, role: raw.role, active: true, createdAt: new Date().toISOString() }, `Created user ${name} (${raw.role})`);
        } catch (ex) {
          throw new Error(`The login was created but saving the profile failed (${friendlyError(ex)}). Open Users and add the profile again, or delete the account in the Firebase console.`);
        }
      }
      m.close();
      toast(u ? 'User updated.' : 'User created. Share the temporary password securely.', 'success');
      renderUsers();
    } catch (ex) {
      console.error(ex);
      $('#form-error', form).textContent = friendlyError(ex);
      btn.disabled = false;
    }
  });
}

async function toggleUser(id) {
  const u = S.users.find((x) => x.id === id);
  if (!u || id === S.uid) return;
  const activate = u.active === false;
  if (!(await confirmDialog(`${activate ? 'Reactivate' : 'Deactivate'} ${u.name}? ${activate ? '' : 'They will no longer be able to use CHOMS.'}`, { confirmText: activate ? 'Reactivate' : 'Deactivate', danger: !activate }))) return;
  try {
    await repo.saveOnline('users', id, { active: activate }, `${activate ? 'Reactivated' : 'Deactivated'} ${u.name}`);
    toast(`${u.name} ${activate ? 'reactivated' : 'deactivated'}.`, 'success');
    renderUsers();
  } catch (e) { toast(friendlyError(e), 'error'); }
}

/* ------------------------------------------------------------------ */
/* Audit trail (FR12) - admin only                                     */
/* ------------------------------------------------------------------ */
async function renderAudit() {
  $('#view').innerHTML = '<div class="loading">Loading audit trail...</div>';
  try { S.data.auditLogs = await repo.list('auditLogs'); } catch (e) { toast(friendlyError(e), 'error'); }
  const term = S.search.audit || '';
  const rows = [...S.data.auditLogs].sort((a, b) => String(b.at).localeCompare(String(a.at))).filter((r) => matchesSearch(`${r.userName} ${r.action} ${r.collection} ${r.summary}`, term)).slice(0, 300);
  $('#view').innerHTML = `<div class="toolbar"><input type="search" class="search" data-search="audit" placeholder="Search audit log..." value="${esc(term)}"/><span class="spacer"></span><span class="muted">Showing latest ${rows.length}</span></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>User</th><th>Action</th><th>Record</th><th>Detail</th></tr></thead><tbody>
    ${rows.map((r) => `<tr><td data-label="When">${esc(String(r.at).replace('T', ' ').slice(0, 16))}</td><td data-label="User">${esc(r.userName)}<small class="muted"> ${esc(r.role || '')}</small></td><td data-label="Action">${badge(r.action === 'delete' ? 'cancelled' : r.action === 'create' ? 'completed' : 'booked').replace(/>[a-z]+</, `>${esc(r.action)}<`)}</td><td data-label="Record">${esc(r.collection)}</td><td data-label="Detail">${esc(r.summary)}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">No audit entries.</td></tr>'}
    </tbody></table></div>`;
}

/* ------------------------------------------------------------------ */
/* Event delegation                                                    */
/* ------------------------------------------------------------------ */
const ACTIONS = {
  add: (d) => openEntityForm(d.entity),
  edit: (d) => openEntityForm(d.entity, d.id),
  delete: (d) => deleteRecord(d.entity, d.id),
  'view-case': (d) => openCase(d.id),
  'schedule-visit': () => openEntityForm('visits', null, { status: 'scheduled', date: addDays(todayISO(), 1) }),
  'complete-visit': (d) => {
    const v = S.data.visits.find((x) => x.id === d.id);
    if (v) openEntityForm('visits', d.id, { ...v, status: 'completed', date: v.date > todayISO() ? todayISO() : v.date });
  },
  'cancel-appt': async (d) => {
    if (await confirmDialog('Cancel this appointment?', { confirmText: 'Cancel appointment', danger: true })) patchRecord('appointments', d.id, { status: 'cancelled', reminderChannel: 'none', reminderDue: '' }, 'Appointment cancelled.');
  },
  'save-report': saveReport,
  'export-report': () => { const s = S.report.summary; if (s) downloadFile(`CHOMS-report-${s.from}-to-${s.to}.csv`, reportCSV(s)); },
  'print-report': () => window.print(),
  'open-report': (d) => {
    const r = S.data.reports.find((x) => x.id === d.id);
    if (!r) return;
    try {
      const s = JSON.parse(r.summaryJson);
      S.report = { from: s.from, to: s.to, summary: s };
      const m = openModal({ title: 'Saved report', wide: true, body: reportHTML(s, { saved: true, status: r.status }), footer: '<button class="btn" data-close>Close</button>' });
      $('[data-action=export-report]', m.el)?.addEventListener('click', () => ACTIONS['export-report']());
      $('[data-action=print-report]', m.el)?.addEventListener('click', () => window.print());
    } catch { toast('This report could not be read.', 'error'); }
  },
  'approve-report': async (d) => {
    if (!(await confirmDialog('Approve this report for funder submission?', { confirmText: 'Approve' }))) return;
    try {
      await repo.save('reports', d.id, { status: 'approved', approvedBy: S.profile.name, approvedAt: new Date().toISOString() }, { isNew: false, summary: 'Report approved' });
      S.data.reports = await repo.list('reports');
      toast('Report approved.', 'success');
      renderReports();
    } catch (e) { toast(friendlyError(e), 'error'); }
  },
  'delete-report': async (d) => {
    if (!(await confirmDialog('Delete this saved report?', { confirmText: 'Delete', danger: true }))) return;
    try { await repo.remove('reports', d.id, { summary: 'Report deleted' }); S.data.reports = await repo.list('reports'); renderReports(); } catch (e) { toast(friendlyError(e), 'error'); }
  },
  'add-user': () => openUserForm(),
  'edit-user': (d) => openUserForm(d.id),
  'toggle-user': (d) => toggleUser(d.id)
};

document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-action]');
  if (t && ACTIONS[t.dataset.action] && !t.closest('.modal-overlay[data-skip]')) {
    // modal-local buttons (open-report) wire their own handlers
    if (t.closest('.modal-overlay') && ['export-report', 'print-report'].includes(t.dataset.action)) return;
    ACTIONS[t.dataset.action](t.dataset);
  }
  if (e.target.closest('#menu-btn')) $('#sidebar').classList.toggle('open');
  else if (!e.target.closest('#sidebar')) $('#sidebar')?.classList.remove('open');
  if (e.target.closest('#logout-btn')) logout();
  if (e.target.closest('#sync-btn')) {
    repo.flush().then(async (r) => { reportSyncResult(r); await refreshView(); }).catch((ex) => toast(friendlyError(ex), 'error'));
  }
});

document.addEventListener('input', (e) => {
  const s = e.target.closest('[data-search]');
  if (!s) return;
  S.search[s.dataset.search] = s.value;
  if (s.dataset.search === 'audit') renderAudit();
  else paintTable(s.dataset.search);
});

document.addEventListener('change', (e) => {
  const f = e.target.closest('[data-filter]');
  if (f) { S.filter[f.dataset.filter] = f.value; paintTable(f.dataset.filter); }
});

init();
